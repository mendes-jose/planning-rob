% NLOPT_G_MLSL: Multi-level single-linkage (MLSL), random (global, needs sub-algorithm)
%
% See nlopt_minimize for more information.
function val = NLOPT_G_MLSL
  val = 38;
