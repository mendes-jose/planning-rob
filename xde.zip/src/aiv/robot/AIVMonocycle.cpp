#include "aiv/robot/AIVMonocycle.hpp"

namespace aiv 
{

AIVMonocycle::AIVMonocycle(std::string name, Application * app)
  : AIV(name, app)
{
}

}


// cmake:sourcegroup=Robot