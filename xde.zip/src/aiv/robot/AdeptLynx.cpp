#include "aiv/robot/AdeptLynx.hpp"

namespace aiv
{

AdeptLynx::AdeptLynx(std::string name, Application * app)
  : AIVMonocycle(name, app)
{
}

double AdeptLynx::getCurrentRightWheelVelocity()
{
  return rightDriveHinge.getJointVelocities()[0];
}

double AdeptLynx::getCurrentLeftWheelVelocity()
{
  return leftDriveHinge.getJointVelocities()[0];
}

void AdeptLynx::setDesiredRightWheelVelocity(double radpersec)
{
  rightDriveHinge.setDesiredJointVelocity( radpersec );
}

void AdeptLynx::setDesiredLeftWheelVelocity(double radpersec)
{
  leftDriveHinge.setDesiredJointVelocity( radpersec );
}

Eigen::Displacementd AdeptLynx::getCurrentPosition()
{
  return frame.getPosition();
}

Eigen::Twistd AdeptLynx::getCurrentVelocity()
{
  return frame.getVelocity();
}

double AdeptLynx::getWheelRadius()
{
  double collisionOffset = rightDriveWheel.getComposite().getOffset();
  
  double wheelRadius = (rightDriveWheel.getComposite().getTriMesh(
      name+std::string("_rightDriveWheel.mesh")).getDilation()+
      leftDriveWheel.getComposite().getTriMesh(
      name+std::string("_leftDriveWheel.mesh")).getDilation())/2.;

  return wheelRadius + collisionOffset;
}
 
double AdeptLynx::getTrack()
{
  double collisionOffset = rightDriveWheel.getComposite().getOffset();

  double track = (leftDrivePrisma.get_H_0().getTranslation()-rightDrivePrisma.get_H_0().getTranslation()).norm();

  return 2*collisionOffset + track;
}

}


// cmake:sourcegroup=Robot