#include "aiv/robot/AIV.hpp"

namespace aiv 
{

AIV::AIV(std::string n, Application * a)
  : name(n)
  , app(a)
{
}

std::string AIV::getName()
{
  return name;
}

PathPlanner * AIV::getPathPlanner()
{
  return planner;
}

Controller * AIV::getController()
{
  return ctrler;
}

}


// cmake:sourcegroup=Robot