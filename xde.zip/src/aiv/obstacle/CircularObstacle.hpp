#ifndef __AIV_CIRCULAROBSTACLE_HPP__
#define __AIV_CIRCULAROBSTACLE_HPP__
#pragma once

#include "aiv/Application.hpp"
#include "aiv/obstacle/Obstacle.hpp"

namespace aiv
{

class CircularObstacle: public Obstacle
{
  friend class ObstBuilder;
public:
  CircularObstacle(std::string name, Application * app);
  ~CircularObstacle(){};

protected:
  double radius;
};

}
#endif //__AIV_CIRCULAROBSTACLE_HPP__
// cmake:sourcegroup=Obstacle