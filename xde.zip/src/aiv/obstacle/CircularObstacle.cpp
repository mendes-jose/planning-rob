#include "aiv/obstacle/CircularObstacle.hpp"

namespace aiv 
{

CircularObstacle::CircularObstacle(std::string name, Application * app)
  : Obstacle(name, app)
{
}

}
// cmake:sourcegroup=Obstacle