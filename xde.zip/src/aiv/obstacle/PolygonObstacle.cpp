#include "aiv/obstacle/PolygonObstacle.hpp"

namespace aiv 
{

PolygonObstacle::PolygonObstacle(std::string name, Application * app)
  : Obstacle(name, app)
{
}

}
// cmake:sourcegroup=Obstacle