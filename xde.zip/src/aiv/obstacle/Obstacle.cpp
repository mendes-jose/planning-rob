#include "aiv/obstacle/Obstacle.hpp"

namespace aiv 
{

Obstacle::Obstacle(std::string name, Application * app)
  : name(name)
  , app(app)
{
}

std::string Obstacle::getName() const
{
  return name;
}

Eigen::Matrix<double, 3, 1> Obstacle::getPosition()
{
  return object.getPosition().getTranslation();
}

}
// cmake:sourcegroup=Obstacle