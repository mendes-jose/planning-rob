#ifndef __AIV_OBSTACLE_HPP__
#define __AIV_OBSTACLE_HPP__
#pragma once

#include "aiv/Application.hpp"

namespace aiv
{
class Obstacle
{
public:
  Obstacle(std::string name, Application * app);
  virtual ~Obstacle(){};

public:
  std::string getName() const;

  Eigen::Matrix<double, 3, 1> getPosition();

  /*!
    Get the (updated) velocity wrt the global
    inertial frame, i.e. \f$T_{body}^{body, 0}(q,t)\f$.
  */
  //virtual Eigen::Twistd getCurrentVelocity() = 0;

protected:
  Application * app;
  std::string   name;
  xde::gvm::RigidBodyRef object;
};

}

#endif // __AIV_OBSTACLE_HPP__

// cmake:sourcegroup=Obstacle