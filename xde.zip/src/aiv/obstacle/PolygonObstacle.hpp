#ifndef __AIV_POLYGONOBSTACLE_HPP__
#define __AIV_POLYGONOBSTACLE_HPP__
#pragma once

#include "aiv/Application.hpp"
#include "aiv/obstacle/Obstacle.hpp"

namespace aiv
{

class PolygonObstacle: public Obstacle
{
  friend class ObstBuilder;
public:
  PolygonObstacle(std::string name, Application * app);
  ~PolygonObstacle(){};

protected:
  // vetices
};

}
#endif //__AIV_POLYGONOBSTACLE_HPP__
// cmake:sourcegroup=Obstacle