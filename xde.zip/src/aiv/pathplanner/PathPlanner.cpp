#include "PathPlanner.hpp"

namespace aiv
{

PathPlanner::PathPlanner(std::string name):
  name(name)
{
}


}


// cmake:sourcegroup=PathPlanner