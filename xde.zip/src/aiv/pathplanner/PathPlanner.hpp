#ifndef __AIV_PATHPLANNER_HPP__
#define __AIV_PATHPLANNER_HPP__
#pragma once

#include <iostream>
#include <Eigen/Dense>
#include <Eigen/Lgsm>

namespace aiv {

class PathPlanner
{
protected:
  std::string name;
public:
  PathPlanner(std::string name);
  virtual void update(const Eigen::Displacementd & realPose, const Eigen::Twistd &realVelocity) = 0;
};

}

#endif // __AIV_PATHPLANNER_HPP__

// cmake:sourcegroup=PathPlanner