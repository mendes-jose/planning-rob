#include <cmath>
#include <limits>
//#include <iostream>
#include "FlatoutputMonocycle.hpp"

namespace aiv
{

Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, 1 > aiv::FlatoutputMonocycle::poseToFlat ( const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &pose )
{
  return pose.block< aiv::FlatoutputMonocycle::flatDim, 1 >(0,0);
}

Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > aiv::FlatoutputMonocycle::flatToPose ( const Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > &dFlat )
{
  return ( Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 >() <<
    dFlat.leftCols(1),
    atan2 ( dFlat(1,1), dFlat(0,1) )
    ).finished();
}

Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > aiv::FlatoutputMonocycle::flatToVelocity ( const Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > &dFlat )
{
  double den = pow(dFlat(0,1), 2) + pow(dFlat(1,1), 2) + std::numeric_limits< float >::epsilon(); //+eps so no /0

  return ( Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1>() <<
      dFlat.block< aiv::FlatoutputMonocycle::flatDim, 1>(0,1).norm(),
      (dFlat(0,1)*dFlat(1,2)-dFlat(1,1)*dFlat(0,2))/den
      ).finished();
}
        
Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > aiv::FlatoutputMonocycle::flatToAcceleration ( const Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+2 > &dFlat )
{
    
  double dflat_norm = dFlat.block< aiv::FlatoutputMonocycle::flatDim, 1 >(0,1).norm();
  double dflat_norm_den = dflat_norm + std::numeric_limits< float >::epsilon();
  double dv = (dFlat(0,1)*dFlat(0,2)+dFlat(1,1)*dFlat(1,2))/dflat_norm_den;
  double dw = ((dFlat(0,2)*dFlat(1,2)+dFlat(1,3)*dFlat(0,1) -
      (dFlat(1,2)*dFlat(0,2)+dFlat(0,3)*dFlat(1,1)))*(pow(dflat_norm, 2)) -
      (dFlat(0,1)*dFlat(1,2)-dFlat(1,1)*dFlat(0,2))*2*dflat_norm*dv)/pow(dflat_norm_den, 4);

  return (Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 >() <<
      dv,
      dw
      ).finished();
}

}


// cmake:sourcegroup=PathPlanner