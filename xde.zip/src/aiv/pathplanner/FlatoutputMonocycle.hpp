#ifndef __AIV_FLATOUTPUTMONOCYCLE_HPP__
#define __AIV_FLATOUTPUTMONOCYCLE_HPP__
#pragma once

#include "Eigen/Dense"

namespace aiv {

class FlatoutputMonocycle
{
public:
    static const unsigned flatDim = 2;
    static const unsigned poseDim = 3;
    static const unsigned velocityDim = 2;
    static const unsigned accelerationDim = 2;
    static const unsigned flatDerivDeg = 2;
    static const unsigned linSpeedIdx = 0;
    static const unsigned angSpeedIdx = 1;
    static const unsigned posIdx = 0;
    static const unsigned posDim = 2;
    /*!
        \brief
        Return z given q.
      
        Return \f$[x\\ y\\ \\theta]^T\f$ given \f$[z\\ \dot{z}\\ \dotsc\\ z^{(l)}]\f$
        (only \f$z\f$ and \f$\dot{z}\f$ are used). \f$\\theta\f$ is in the range
        \f$(-\pi, \pi]\f$.
     
        \f[
            \begin{array}{l}
            \varphi_1(z(t_k),\dotsc,z^{(l)}(t_k))=\\
            \left[\begin{array}{c}
            x\\
            y\\
            \omega
            \end{array}\right]
            \left[\begin{array}{c}
            z_1\\
            z_2\\
            \arctan(\dot{z}_2/\dot{z}_1)\\
            \end{array}\right]
            \end{array}
        \f]
        \param q
        State vector.
     
        \returns
        The flatoutput.
     */
    static Eigen::Matrix< double, flatDim, 1 > poseToFlat ( const Eigen::Matrix< double, poseDim, 1 > &pose );
    static Eigen::Matrix< double, poseDim, 1 > flatToPose ( const Eigen::Matrix< double, flatDim, flatDerivDeg+1 > &dFlat );
    static Eigen::Matrix< double, velocityDim, 1 > flatToVelocity ( const Eigen::Matrix< double, flatDim, flatDerivDeg+1 > &dFlat );
    static Eigen::Matrix< double, velocityDim, 1 > flatToAcceleration ( const Eigen::Matrix< double, flatDim, flatDerivDeg+2 > &dFlat );
};

}
#endif // __AIV_FLATOUTPUTMONOCYCLE_HPP__

// cmake:sourcegroup=PathPlanner