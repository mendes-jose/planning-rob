#include "aiv/pathplanner/PathPlannerRecedingHoriz.hpp"
#include "aiv/pathplanner/FlatoutputMonocycle.hpp"
#include <nlopt.h>
#include <omp.h>
#include <boost/foreach.hpp>
#include <algorithm>

#define foreach_ BOOST_FOREACH

namespace aiv
{

typedef Eigen::Spline< double, aiv::PathPlannerRecedingHoriz::splDim, aiv::PathPlannerRecedingHoriz::splDegree > MySpline;

PathPlannerRecedingHoriz::PathPlannerRecedingHoriz(std::string name, double updateTimeStep)
  : PathPlanner(name)
  , updateTimeStep(updateTimeStep)
  , updateCallCntr(0)
  , lastStepMinDist(0.5)
  , optAccuracy(0.001)
  , lastMaxIteration(25)
  , firstMaxIteration(50)
  , interMaxIteration(20)
  , conflictFreePathDeviation(4.0)
  , interRobotSafetyDist(0.1)
  , nextVelocityRef( Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 >::Zero() )
  , nextPoseRef( Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 >::Zero() )
  , planStage(INITSTAGE)
  , ongoingPlanIdx(-1)
  , executingPlanIdx(-1)
  , standAlone(true)
  , lastPlanExec(false)
{
  this->planOngoingMutex.initialize();
  //this->points_ts.open ("points_ts.csv");
}

PathPlannerRecedingHoriz::~PathPlannerRecedingHoriz()
{
  //this->points_ts.close();
}

void PathPlannerRecedingHoriz::init(
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &initPose, // x, y, theta
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &initVelocity, // v, w
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &targetedPose, // x, y, theta
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &targetedVelocity, // v, w
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &maxVelocity, // v, w
  double compHorizon,
  double refPlanHorizon,
  unsigned noTimeSamples,
  unsigned noIntervNonNull)
{
  this->initPose = initPose;
  this->initFlat = aiv::FlatoutputMonocycle::poseToFlat ( this->initPose );
  this->latestFlat = this->initFlat;
  this->initVelocity = initVelocity;
  this->targetedPose = targetedPose;

  this->targetedFlat = aiv::FlatoutputMonocycle::poseToFlat ( this->targetedPose );
  this->targetedVelocity = targetedVelocity;
  this->maxVelocity = maxVelocity;
  this->mindAcceleration = false;

  this->compHorizon = compHorizon; // computation horizon
  this->refPlanHorizon = refPlanHorizon; // planning horizon
  this->finalPlanHorizon = refPlanHorizon; // planning horizon
  this->planHorizon = refPlanHorizon; // planning horizon
  this->noTimeSamples = noTimeSamples; // number of  time samples taken within a planning horizon
  this->noIntervNonNull  = noIntervNonNull; // number of non null knots intervals
  this->noCtrlPts = noIntervNonNull + this->splDegree;
  this->maxStraightDist = refPlanHorizon * maxVelocity(aiv::FlatoutputMonocycle::linSpeedIdx);

  this->latestFlat = this->initFlat;
  this->latestPose = initPose;
  this->basePose = initPose;
  this->latestVelocity = initVelocity;

  //plTimer.ResetTime();
}

void PathPlannerRecedingHoriz::init(
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &initPose, // x, y, theta
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &initVelocity, // v, w
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &targetedPose, // x, y, theta
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &targetedVelocity, // v, w
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &maxVelocity, // v, w
  const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &maxAcceleration, // dv, dw
  double compHorizon,
  double refPlanHorizon,
  unsigned noTimeSamples,
  unsigned noIntervNonNull)
{
  this->init(initPose, initVelocity, targetedPose, targetedVelocity, maxVelocity, compHorizon, refPlanHorizon, noTimeSamples, noIntervNonNull);
  this->maxAcceleration = maxAcceleration;
}

void PathPlannerRecedingHoriz::setOption ( std::string optionName, double optionValue )
{
  if (optionName == "lastStepMinDist")
  {
    this->lastStepMinDist = optionValue;
  }
  else if (optionName == "optAccuracy")
  {
    this->optAccuracy = optionValue;
  }
  else if (optionName == "conflictFreePathDeviation")
  {
    this->conflictFreePathDeviation = optionValue;
  }
  else if (optionName == "interRobotSafetyDist")
  {
    this->interRobotSafetyDist = optionValue;
  }
  else if (optionName == "lastMaxIteration")
  {
    this->lastMaxIteration = unsigned(optionValue);
  }
  else if (optionName == "firstMaxIteration")
  {
    this->firstMaxIteration = unsigned(optionValue);
  }
  else if (optionName == "interMaxIteration")
  {
    this->interMaxIteration = unsigned(optionValue);
  }
}

Eigen::Array< double, 1, Eigen::Dynamic > PathPlannerRecedingHoriz::genKnots(const double initT, const double finalT, bool nonUniform)
{
    // TODO noIntervNonNull < 2 => error
    
    double d = (finalT-initT)/(4+(this->noIntervNonNull-2));
    // d is the nonuniform interval base value (spacing produce intervals like this: 2*d, d,... , d, 2*d)

    Eigen::Array< double, 1, Eigen::Dynamic > knots(this->splDegree*2 + this->noIntervNonNull+1);

    // first and last knots
    knots.head(this->splDegree) = Eigen::Array< double, 1, Eigen::Dynamic >::Constant(this->splDegree, initT);
    knots.tail(this->splDegree) = Eigen::Array< double, 1, Eigen::Dynamic >::Constant(this->splDegree, finalT);
    
    // intermediaries knots
    if(nonUniform)
    {    
        knots(this->splDegree) = initT;
        knots(this->splDegree+1) = initT+2*d;

        unsigned i = 0;
        for(i = 0; i < this->noIntervNonNull-2; ++i)
        {
            knots(this->splDegree+i+2) = knots(this->splDegree+i+1)+d;
        }

        knots(this->splDegree+2+i) = finalT; // = knots(this->splDegree+2+i-1) + 2*d
    }
    else // uniform
    {
        knots.segment(this->splDegree, this->noIntervNonNull+1) = Eigen::Array< double, 1, Eigen::Dynamic >::LinSpaced(this->noIntervNonNull+1, initT, finalT);
    }
    return knots;
}

void PathPlannerRecedingHoriz::update(const Eigen::Displacementd & realPose, const Eigen::Twistd &realVelocity)
{
  //std::cout << "-------------DISPLACEMENT------------- " << realPose.y() << std::endl;
  double firstPlanTimespan = 2.;
  //double secCurrentTime = plTimer.GetTime()/1000.0;
  double secCurrentTime = updateTimeStep*updateCallCntr;
  //std::cout << "________________ MPL TIME : " << secCurrentTime << "_______________" << std::endl;
  ++updateCallCntr;
  bool updateIndeed = false;
  double evalTime = std::max(std::min(((secCurrentTime-(std::max((this->executingPlanIdx),0)*this->compHorizon))/this->planHorizon), 1.), 0.);

  if ( !this->lastPlanExec )
  {

    // If the robot started to execute the motion:
    if ( this->ongoingPlanIdx > 0 )
    {
      if ( evalTime >= this->compHorizon/this->planHorizon )
      {
        //std::cout << "Eval time before fix " << evalTime << std::endl;
        //std::cout << "Current before fix " << secCurrentTime << std::endl;
        //std::cout << "CompHorizon " << this->compHorizon << std::endl;
        evalTime -= this->compHorizon/this->planHorizon; // "Fix" evalTime
        //std::cout << "Eval time fixed " << evalTime << std::endl;

        if ( !this->planOngoingMutex.try_lock() ) // We are supposed to get this lock
        {
          std::cout << "HECK! Plan didn't finish before computing time expired" << std::endl;
          // "kill" planning thread putting something reasonable in the aux spline
          // OR pause the simulation for a while, waiting for the plan thread to finish (completly unreal) => planThread.join()
          //planThread.join();
          planThread.interrupt();
        }
        // Now we are sure that there is no ongoing planning!

        // update solution spline with the auxliar spline;
        // no need to lock a mutex associated to the auxiliar spline because we are sure there is no ongoing planning
    //    std::cout << "__________\nLATEST POSE C1\n" << this->latestPose << "\n_____________\n";

        this->solSpline = this->auxSpline; // update solution
        this->basePose = this->mLatestPose; // update base pose
        this->mLatestPose = this->latestPose; // get latest position found by the plan that just ended (will be the next base pos)
        
        if ( this->planStage == FINALSTAGE )
        {
          std::cout << "!!!!!Now goint to execute last plan!!!!!" << std::endl;
          this->lastPlanExec = true;
          this->planHorizon = this->finalPlanHorizon;
          this->planOngoingMutex.unlock();
        }
        else
        {
          // plan next section!
          planThread = boost::thread( &PathPlannerRecedingHoriz::plan, this ); // Do PX with X in (1, 2, ..., indefined_finit_value)
          ++this->ongoingPlanIdx;
    //    std::cout << "_______ (C1) Spawn new plan thread!!! ________ " << this->ongoingPlanIdx << std::endl;
        }
        ++this->executingPlanIdx;
      }
      updateIndeed = true;
    }

    // if we are in P0 stage
    else if ( this->ongoingPlanIdx == 0 && secCurrentTime > firstPlanTimespan ) // Time so robot touch the floor
    {

      if ( !this->planOngoingMutex.try_lock() ) // We are supposed to get this lock
      {
        // "kill" planning thread putting something reasonable in the aux spline
        // OR pause the simulation for a while, waiting for the plan thread to finish (completly unreal) => planThread.join()
        std::cout << "HECK! Plan didn't finish before computing time expired" << std::endl;
        planThread.interrupt();
      }
  //    std::cout << "__________\nLATEST POSE C3\n" << this->latestPose << "\n_____________\n";

      // update solution spline with the auxliar spline find in planning 0;
      // no need to lock a mutex associated to the auxiliar spline because we are sure there is no ongoing planning
      this->solSpline = this->auxSpline;
      this->mLatestPose = this->latestPose;

      if ( this->planStage == FINALSTAGE )
      {
        this->lastPlanExec = true;
        this->planHorizon = this->finalPlanHorizon;
        this->planOngoingMutex.unlock();
      }
      else
      {
        planThread = boost::thread( &PathPlannerRecedingHoriz::plan, this ); // Do P1
        ++this->ongoingPlanIdx;
  //      std::cout << "_______ (C3) Spawn new plan thread!!! ________ " << this->ongoingPlanIdx << std::endl;
      }
      ++this->executingPlanIdx;

      //plTimer.ResetTime();
      updateCallCntr = 0;

      //secCurrentTime = plTimer.GetTime();
      secCurrentTime = updateTimeStep*updateCallCntr;
      evalTime = std::max(std::min((secCurrentTime/this->planHorizon), 1.), 0.);

      updateIndeed = true;
    }

    // if the update function is being called by the first time (INIT stage)
    else if ( this->ongoingPlanIdx == -1 )
    {
      this->planOngoingMutex.lock();
      planThread = boost::thread( &PathPlannerRecedingHoriz::plan, this ); // Do P0
      ++this->ongoingPlanIdx;
  //    std::cout << "__________\nLATEST POSE C2\n" << this->latestPose << "\n_____________\n";
  //    std::cout << "_______ (C2) Spawn new plan thread!!! ________ " << this->ongoingPlanIdx << std::endl;
    }
  }

  else
  {
    updateIndeed = true;
  }

  if ( updateIndeed )
  {
    // just use solSpline to get the nextReferences values
    Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > derivFlat =
        solSpline.derivatives(
        evalTime, aiv::FlatoutputMonocycle::flatDerivDeg
        ).block< aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 >(1, 0);
    
    this->nextPoseRef = aiv::FlatoutputMonocycle::flatToPose ( derivFlat );

    this->nextPoseRef.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0) =
        this->nextPoseRef.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0)+
        this->basePose.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0);
    
    this->nextVelocityRef = aiv::FlatoutputMonocycle::flatToVelocity ( derivFlat );
    //this->nextVelocityRef = Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 >::Constant(2.0);

    //double timeAtMaximum = 20;
    //double maxLin = .8;
    //double maxAng = .5;
    //double atangTimeShift = 6.; //seconds

    //if (secCurrentTime < timeAtMaximum - firstPlanTimespan)
    //{
    //  this->nextVelocityRef = (Eigen::Vector2d() <<
    //      maxLin/(-1.*atan(-atangTimeShift)+3.1415/2.)*
    //      (atan(secCurrentTime-atangTimeShift)-atan(-atangTimeShift)),
    //      //0.0,
    //      maxAng/(-1.*atan(-atangTimeShift)+3.1415/2.)*(atan(secCurrentTime-atangTimeShift)-atan(-atangTimeShift))).finished();
    //      //.0).finished();
    //}
    //else if (secCurrentTime < 2.*(timeAtMaximum - firstPlanTimespan))
    //{
    //  this->nextVelocityRef = (Eigen::Vector2d() <<
    //      maxLin/(-1.*atan(-atangTimeShift)+3.1415/2.)*(-1.*atan(secCurrentTime-2.*
    //      (timeAtMaximum - firstPlanTimespan)+atangTimeShift)- atan(-atangTimeShift)),
    //      //0.0,
    //      maxAng/(-1.*atan(-atangTimeShift)+3.1415/2.)*(-1.*atan(secCurrentTime-2.*(timeAtMaximum - firstPlanTimespan-atangTimeShift)-atangTimeShift)
    //      -atan(-atangTimeShift))).finished();
    //      //.0).finished();
    //}
    //else
    //{
    //  this->nextVelocityRef = (Eigen::Vector2d() <<
    //      .0,
    //      -1.*maxAng/(-1.*atan(-atangTimeShift)+3.1415/2.)*(atan(secCurrentTime-3.*
    //      (timeAtMaximum - firstPlanTimespan-atangTimeShift)-atangTimeShift)-atan(-atangTimeShift))).finished();;
    //}
  }
  return;
  // TODO add another condition associated with the "belief" in the robot vision of the next obstacle configuration otherwise is better wait
}

// update auxSpline
void PathPlannerRecedingHoriz::plan()
{
  //std::cout << "CTROL FROM PLAN\n" << this->auxSpline.ctrls() << std::endl;
  //boost::this_thread::sleep(boost::posix_time::milliseconds(100));
  /* INITIALIZATION OF CTRL PTS
  _______________________________________*/
  // Use auxSpline with old solution to initiate the new one
  // Estimate the position of the point
  //std::cout << "Max straigth dist" << this->maxStraightDist << std::endl << std::endl << std::endl;

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, 1 > remainingDistVectorUni = (this->targetedFlat - this->latestFlat);
  double remainingDist = remainingDistVectorUni.norm();
  remainingDistVectorUni /= remainingDist;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, 1 > lastCtrlPt = this->maxStraightDist*remainingDistVectorUni;

  if (remainingDist < this->lastStepMinDist + this->compHorizon*this->initVelocity[aiv::FlatoutputMonocycle::linSpeedIdx])
  {
    //exit(0);
    //system("pause");
    this->planStage = FINALSTAGE;
    //estimate time
    this->finalPlanHorizon = this->refPlanHorizon; //TODO change the estimate
  }


  /*std::cout << direction << std::endl;
  std::cout << direction.norm() << std::endl;*/

  // Interpolation time
  Eigen::RowVectorXd interpTime;
  if (this->planStage == FINALSTAGE )
    interpTime = Eigen::RowVectorXd::LinSpaced(this->noCtrlPts, 0.0, this->finalPlanHorizon);
  else
    interpTime = Eigen::RowVectorXd::LinSpaced(this->noCtrlPts, 0.0, this->refPlanHorizon);

  // Interpolation points ( noCtrlPts points )
  MySpline::ControlPointVectorType points ( this->splDim, this->noCtrlPts );
  points.row(0) = interpTime;

  switch(this->planStage) //TODO
  {
    case INTERSTAGE:
      for ( auto i = 1; i < splDim; ++i )
      {
        points.row(i) = Eigen::RowVectorXd::LinSpaced( this->noCtrlPts, 0.0, lastCtrlPt(i-1) );
      }
      break;
    case INITSTAGE:
      for ( auto i = 1; i < splDim; ++i )
      {
        points.row(i) = Eigen::RowVectorXd::LinSpaced( this->noCtrlPts, 0.0, lastCtrlPt(i-1) );
      }
      break;
    case FINALSTAGE:
      for ( auto i = 1; i < splDim; ++i )
      {
        points.row(i) = Eigen::RowVectorXd::LinSpaced( this->noCtrlPts, 0.0, lastCtrlPt(i-1) );
      }
      break;
  }

  // Get chords lengths from interpolation time
  MySpline::KnotVectorType chordLengths;
  Eigen::ChordLengths(interpTime, chordLengths);

  // Call fitting static method
  this->auxSpline = Eigen::SplineFitting<MySpline>::Interpolate( points, splDegree, chordLengths );
  
  //std::cout << this->auxSpline.ctrls() << std::endl;
  //system("pause");

  /*Eigen::ArrayXd optParam(this->splDim-1, this->noCtrlPts);
  optParam = this->auxSpline.ctrls().block(1, 0, this->splDim-1, this->noCtrlPts);
  for ( unsigned i = 0; i < this->noCtrlPts*aiv::FlatoutputMonocycle::flatDim; ++i )
  {
    std::cout << optParam(i/(this->splDim-1), i%(this->splDim-1)) << std::endl;
  }*/

  /* CALL OPT SOLVER (in stand alone mode) 
  _______________________________________*/

  this->standAlone = true;

  this->solveOptPbl();

  /* GET RESULTS
  _______________________________________*/


  /* UPDATES
  _______________________________________*/
  // update latest flatoutput and pose for the new planning

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > derivFlat =
      auxSpline.derivatives(
      this->compHorizon/this->refPlanHorizon, aiv::FlatoutputMonocycle::flatDerivDeg
      ).block< aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 >(1, 0);

  this->latestFlat += derivFlat.col(0);
  //std::cout << "__________\nLatest flat\n" << this->latestFlat << "\n_____________\n";

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > latestPoseIncrement;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > auxLatestPose;

  auxLatestPose = this->latestPose;

  this->latestPose = aiv::FlatoutputMonocycle::flatToPose ( derivFlat );
  //std::cout << "__________\nflatToPose call on deriv at tc/tp\n" << this->latestPose << "\n_____________\n";
  this->latestPose.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0) +=
      auxLatestPose.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0);

  this->latestVelocity = aiv::FlatoutputMonocycle::flatToVelocity ( derivFlat );

  switch(this->planStage)
  {
    case FINALSTAGE:
      break;
    case INITSTAGE:
      this->planStage = INTERSTAGE;
      break;
      // REDO TIME AND KNOTS
  }
  std::cout << "__________\nLATEST POSE\n" << this->latestPose << "\n_____________\n";
  //boost::this_thread::sleep(boost::posix_time::milliseconds(1000));
  this->planOngoingMutex.unlock();
  return;
}

void PathPlannerRecedingHoriz::solveOptPbl()
{
  unsigned nParam;
  unsigned nEq;
  unsigned nIneq;
  double (*objF) (unsigned, const double *, double *, void *);
  void (*eqF) (unsigned, double *, unsigned, const double*, double*, void*);
  void (*ieqF) (unsigned, double *, unsigned, const double*, double*, void*);

  double *optParam;
  double *tolEq;
  double *tolIneq;

  switch(this->planStage)
  {
    case INTERSTAGE:
      objF = PathPlannerRecedingHoriz::objectFunc;
      eqF = PathPlannerRecedingHoriz::eqFunc;
      ieqF = PathPlannerRecedingHoriz::ineqFunc;
      nParam = this->noCtrlPts*aiv::FlatoutputMonocycle::flatDim;
      nEq = aiv::FlatoutputMonocycle::poseDim + aiv::FlatoutputMonocycle::velocityDim;
      nIneq = aiv::FlatoutputMonocycle::velocityDim * (this->noTimeSamples-1)+
          aiv::FlatoutputMonocycle::accelerationDim * (this->noTimeSamples-1);

      optParam = new double[nParam];
      for ( unsigned i = 0; i < nParam; ++i )
      {
        optParam[i] = this->auxSpline.ctrls()(i%(this->splDim-1)+1, i/(this->splDim-1));
      }

      tolEq = new double[nEq];
      for ( unsigned i = 0; i < nEq; ++i )
      {
        tolEq[i] = this->optAccuracy;
      }

      tolIneq = new double[nIneq];
      for ( unsigned i = 0; i < nIneq; ++i )
      {
        tolIneq[i] = this->optAccuracy;
      }
      break;
    case INITSTAGE:
      objF = PathPlannerRecedingHoriz::objectFunc;
      eqF = PathPlannerRecedingHoriz::eqFunc;
      ieqF = PathPlannerRecedingHoriz::ineqFunc;
      nParam = this->noCtrlPts*aiv::FlatoutputMonocycle::flatDim;
      nEq = aiv::FlatoutputMonocycle::poseDim + aiv::FlatoutputMonocycle::velocityDim;
      nIneq = aiv::FlatoutputMonocycle::velocityDim * (this->noTimeSamples-1)+
          aiv::FlatoutputMonocycle::accelerationDim * (this->noTimeSamples-1);

      optParam = new double[nParam];
      for ( unsigned i = 0; i < nParam; ++i )
      {
        // get ctrl pts matrix => p1x, p1y, p2x, p2y...
        optParam[i] = this->auxSpline.ctrls()(i%(this->splDim-1)+1, i/(this->splDim-1));
      }

      tolEq = new double[nEq];
      for ( unsigned i = 0; i < nEq; ++i )
      {
        tolEq[i] = this->optAccuracy;
      }

      tolIneq = new double[nIneq];
      for ( unsigned i = 0; i < nIneq; ++i )
      {
        tolIneq[i] = this->optAccuracy;
      }
      
      break;
    case FINALSTAGE:
      objF = PathPlannerRecedingHoriz::objectFuncLS;
      eqF = PathPlannerRecedingHoriz::eqFuncLS;
      ieqF = PathPlannerRecedingHoriz::ineqFuncLS;
      nParam = this->noCtrlPts*aiv::FlatoutputMonocycle::flatDim + 1;
      nEq = (aiv::FlatoutputMonocycle::poseDim + aiv::FlatoutputMonocycle::velocityDim)*2;
      nIneq = aiv::FlatoutputMonocycle::velocityDim * (this->noTimeSamples-2)+
          aiv::FlatoutputMonocycle::accelerationDim * (this->noTimeSamples-2);

      optParam = new double[nParam];
      optParam[0] = this->finalPlanHorizon;
      for ( unsigned i = 1; i < nParam; ++i )
      {
        optParam[i] = this->auxSpline.ctrls()((i-1)%(this->splDim-1)+1, (i-1)/(this->splDim-1));
      }

      tolEq = new double[nEq];
      for ( unsigned i = 0; i < nEq; ++i )
      {
        tolEq[i] = this->optAccuracy;
      }

      tolIneq = new double[nIneq];
      for ( unsigned i = 0; i < nIneq; ++i )
      {
        tolIneq[i] = this->optAccuracy;
      }
      break;
  }

  nlopt_opt opt = nlopt_create(NLOPT_LN_COBYLA, nParam); /* algorithm and dimensionality */
  //nlopt_opt opt = nlopt_create(NLOPT_LD_SLSQP, nParam); /* algorithm and dimensionality */
  
  //std::cout << "Adding obj func " << std::endl;
  nlopt_set_min_objective(opt, objF, this);

  //std::cout << "Adding equation " << std::endl;
  nlopt_add_equality_mconstraint (opt, nEq, eqF, this, tolEq);
  nlopt_add_inequality_mconstraint (opt, nIneq, ieqF, this, tolIneq);

  //TODO
  nlopt_set_xtol_rel(opt, 1e-4);

  double minf;

  /*std::cout << "The contents of auxvector are:";
  for (unsigned i=0; i<nParam; ++i)
    std::cout << ' ' << optParam[i];
  std::cout << '\n';*/
  int i = nlopt_optimize(opt, optParam, &minf);
  //int i=1;
  if ( i < 0) {
    printf("_______________________________________nlopt failed!\n");
    //system("pause");
    std::cout << "objectif func value: " << minf << std::endl;
    std::cout << "with error: " << i << std::endl;
  }
  MySpline::ControlPointVectorType ctrlPts(this->splDim, this->noCtrlPts);

  MySpline::KnotVectorType knots;

  //update spline
  switch(this->planStage)
  {
    case INTERSTAGE:
    case INITSTAGE:
      ctrlPts.row(0) = this->auxSpline.ctrls().row(0);
      for ( unsigned i = 0; i < nParam; ++i )
      {
        // get ctrl pts matrix => p1x, p1y, p2x, p2y...
        ctrlPts(i%(this->splDim-1)+1, i/(this->splDim-1)) = optParam[i];
      }

      knots = this->auxSpline.knots();
      //std::cout << knots << std::endl << std::endl;
      this->auxSpline.~MySpline();
      new (&this->auxSpline) MySpline(knots, ctrlPts);

      break;
    case FINALSTAGE:
      // get new knots TODO

      // get new time
      ctrlPts.row(0) = Eigen::Array< double, 1, Eigen::Dynamic >::LinSpaced(this->noCtrlPts, 0.0, optParam[0]);
      this->finalPlanHorizon = ctrlPts(0,this->noCtrlPts-1);

      // get the rest of the ctrl pts
      for ( unsigned i = 1; i < nParam; ++i )
      {
        // get ctrl pts matrix => p1x, p1y, p2x, p2y...
        ctrlPts((i-1)%(this->splDim-1)+1, (i-1)/(this->splDim-1)) = optParam[i];
      }

      //knots = this->auxSpline.knots();
      //std::cout << knots << std::endl << std::endl;
      //this->auxSpline.~MySpline();
      //new (&this->auxSpline) MySpline(knots, ctrlPts);

      break;
  }

  nlopt_destroy(opt);
  delete[] optParam;
  delete[] tolEq;
  delete[] tolIneq;
}

double PathPlannerRecedingHoriz::objectFunc(unsigned n, const double *x, double *grad, void *my_func_data)
{
  //std::cout << "OBJECT FUN CALL\n";

  // get this path planner pointer
  PathPlannerRecedingHoriz *thisPP = static_cast<PathPlannerRecedingHoriz *>(my_func_data);

  MySpline::ControlPointVectorType ctrlPts(thisPP->splDim, thisPP->noCtrlPts);

  ctrlPts.row(0) = thisPP->auxSpline.ctrls().row(0);
  for ( unsigned i = 0; i < n; ++i )
  {
    ctrlPts(i%(thisPP->splDim-1)+1, i/(thisPP->splDim-1)) = x[i];
    //std::cout << x[i] << std::endl;
  }

  //std::cout << "CTRL PTS BASED ON OPT:\n" << ctrlPts << std::endl;

  MySpline optSpline(thisPP->auxSpline.knots(), ctrlPts);

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > derivFlat =
        optSpline.derivatives(
        1.0, aiv::FlatoutputMonocycle::flatDerivDeg
        ).block< aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 >(1, 0);

  //std::cout << "EVAL SPLINE AT END: " << optSpline(1.0) << std::endl;

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > poseAtTp = aiv::FlatoutputMonocycle::flatToPose ( derivFlat );

  //std::cout << "DERIV:\n" << derivFlat << std::endl;

  /*double pt2TargetDist = (thisPP->targetedFlat - thisPP->latestFlat).norm();
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > pt2TargetVec;*/

  double cost = (poseAtTp.block(aiv::FlatoutputMonocycle::posIdx, 0, aiv::FlatoutputMonocycle::posDim, 1) -
      (thisPP->targetedPose.block(aiv::FlatoutputMonocycle::posIdx, 0, aiv::FlatoutputMonocycle::posDim, 1) -
      thisPP->latestPose.block(aiv::FlatoutputMonocycle::posIdx, 0, aiv::FlatoutputMonocycle::posDim, 1))).squaredNorm();

  //std::cout << "COST: " << cost << std::endl;

  if (grad)
  {
    for ( unsigned i = n-1, j = 0; i > n - (thisPP->splDim-1) - 1; --i, ++j)
    {
      grad[i] = 2*(x[i]-
          (thisPP->targetedPose(i%(thisPP->splDim-1)+aiv::FlatoutputMonocycle::posIdx,0) -
          thisPP->latestPose(i%(thisPP->splDim-1)+aiv::FlatoutputMonocycle::posIdx,0)));
      std::cout << "GRAD@" << i << ": " << grad[i] << std::endl;
      std::cout << "target@" << i << ": " << thisPP->targetedPose(i%(thisPP->splDim-1)+aiv::FlatoutputMonocycle::posIdx,0) << std::endl;
    }
    for ( unsigned i=0; i < n-(thisPP->splDim-1); ++i)
    {
      grad[i] = 0.0;
      std::cout << "GRAD@" << i << ": " << grad[i] << std::endl;
    }
  }
  /*else
  {
    system("pause");
  }*/

  return cost;
}

void PathPlannerRecedingHoriz::eqFunc(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data)
{
  //std::cout << "EQ FUN CALL" << std::endl;

  //std::cout << sizeof(grad) / sizeof(grad[0]) << std::endl;

  //std::cout << "RESUL DIM " << m << std::endl;
  //std::cout << "CTRLPT DIM " << n << std::endl;

  PathPlannerRecedingHoriz *thisPP = static_cast<PathPlannerRecedingHoriz *>(data);

  MySpline::ControlPointVectorType ctrlPts(thisPP->splDim, thisPP->noCtrlPts);

  ctrlPts.row(0) = thisPP->auxSpline.ctrls().row(0);
  for ( unsigned i = 0; i < n; ++i )
  {
    ctrlPts(i%(thisPP->splDim-1)+1, i/(thisPP->splDim-1)) = x[i];
    //std::cout << x[i] << std::endl;
  }

  //std::cout << "CTRL PTS BASED ON OPT:\n" << ctrlPts << std::endl;

  MySpline optSpline(thisPP->auxSpline.knots(), ctrlPts);

  //std::cout << "EVAL SPLINE AT END:\n" << optSpline(1.0) << std::endl;
  //std::cout << "EVAL SPLINE AT init:\n" << optSpline(0.0) << std::endl;

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > derivFlat;

  derivFlat =
        optSpline.derivatives(
        0.0, aiv::FlatoutputMonocycle::flatDerivDeg
        ).bottomRows(aiv::FlatoutputMonocycle::flatDim);

  //std::cout << "DERIV@0:\n" << derivFlat << std::endl;

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > poseAtT0 = aiv::FlatoutputMonocycle::flatToPose ( derivFlat );
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > diffPoseAtT0 = poseAtT0 - thisPP->latestPose;
  diffPoseAtT0.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0) = poseAtT0.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0);

  //std::cout << "LATEST VEL\n" << thisPP->latestVelocity << std::endl;

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > diffVelocityAtT0 = aiv::FlatoutputMonocycle::flatToVelocity ( derivFlat ) - thisPP->latestVelocity;

  int i = 0;
  //std::cout << "POS ERROR\n";
  for (; i < aiv::FlatoutputMonocycle::poseDim; ++i )
  {
    result[i] = diffPoseAtT0[i];
    //std::cout << ' ' << result[i];
  }
  //std::cout << "\nVEL ERROR\n";
  for ( int j = i; j-i < aiv::FlatoutputMonocycle::velocityDim; ++j )
  {
    result[j] = diffVelocityAtT0[j-i];
    //std::cout << ' ' << result[j];
  }

  /*std::cout << "\nEQ FUNC CALL RESULTS:\n";

  for (unsigned i = 0; i<m; ++i)
  {
    std::cout << ' ' << result[i];
  }
  std::cout << '\n';*/

  if (grad)
  {
    int i=0;
    std::cout << "grad order ? = " << n*m <<std::endl;
    //while (true)
      //std::cout << "grad@" << i++ << " = " << grad[i] << std::endl;
    //system("pause");
  }
  /*else
  {
    system("pause");
  }*/

  //std::cout << m << std::endl;
  //system("pause");
  return;
}

void PathPlannerRecedingHoriz::ineqFunc(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data)
{
  //std::cout << "INEQ FUN CALL" << std::endl;

  PathPlannerRecedingHoriz *thisPP = static_cast<PathPlannerRecedingHoriz *>(data);

  MySpline::ControlPointVectorType ctrlPts(thisPP->splDim, thisPP->noCtrlPts);

  ctrlPts.row(0) = thisPP->auxSpline.ctrls().row(0);
  for ( unsigned i = 0; i < n; ++i )
  {
    ctrlPts(i%(thisPP->splDim-1)+1, i/(thisPP->splDim-1)) = x[i];
    //std::cout << x[i] << std::endl;
  }

  //std::cout << "CTRL PTS BASED ON OPT:\n" << ctrlPts << std::endl;

  MySpline optSpline(thisPP->auxSpline.knots(), ctrlPts);

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1+1 > derivFlat;

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > velocity;

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::accelerationDim, 1 > acceleration;

  #pragma omp parallel for
  for ( int i = 1; i < int(thisPP->noTimeSamples); ++i )
  {

    derivFlat =
        optSpline.derivatives(
        double(i)/(thisPP->noTimeSamples-1), aiv::FlatoutputMonocycle::flatDerivDeg+1
        ).bottomRows(aiv::FlatoutputMonocycle::flatDim);

    velocity = aiv::FlatoutputMonocycle::flatToVelocity ( derivFlat.leftCols(aiv::FlatoutputMonocycle::flatDim+1) );

    acceleration = aiv::FlatoutputMonocycle::flatToAcceleration ( derivFlat );

    /*std::cout << "DERIV \n" << derivFlat << std::endl;

    std::cout << "VEL \n" << velocity.cwiseAbs() << std::endl;
    std::cout << "MVEL \n" << thisPP->maxVelocity << std::endl;*/
    int j;
    for ( j = 0; j < aiv::FlatoutputMonocycle::velocityDim; ++j )
    {
      result[j+(i-1)*aiv::FlatoutputMonocycle::velocityDim] = velocity.cwiseAbs()(j, 0) - thisPP->maxVelocity(j,0);
    }

    for ( int k = j; k-j < aiv::FlatoutputMonocycle::accelerationDim; ++k )
    {
      result[k+(i-1)*aiv::FlatoutputMonocycle::accelerationDim] = acceleration.cwiseAbs()(k-j, 0) - thisPP->maxAcceleration(k-j,0);
    }

    /*for (unsigned a = 0;  a < m; ++a)
    {
      if (result[a] > 0)
      {
        std::cout << "Result: " << result[a] << std::endl;
      }
    }*/

  }

  /*std::cout << "INEQ FUN CALL" << std::endl;

  std::cout << "\nINEQ FUNC CALL RESULTS:\n";

  for (unsigned i = 0; i<m; ++i)
  {
    std::cout << ' ' << result[i];
  }
  std::cout << '\n';*/

  //std::cout << std::endl;
  if (grad)
  {
  }
  /*else
  {
    system("pause");
  }*/
  return;
}

double PathPlannerRecedingHoriz::objectFuncLS(unsigned n, const double *x, double *grad, void *my_func_data)
{
  //std::cout << "OBJECT LS FUN CALL\n";
  if (grad)
  {
    grad[0] = 2*x[0];
    for ( unsigned i=1; i < n; ++i)
    {
      grad[i] = 0.0;
    }
  }
  /*else
  {
    system("pause");
  }*/

  double cost = pow(x[0], 2);
  //std::cout << "COST LS: " << cost << std::endl;
  return cost;
}

void PathPlannerRecedingHoriz::eqFuncLS(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data)
{
  //std::cout << sizeof(grad) / sizeof(grad[0]) << std::endl;

  std::cout << "EQ RESUL DIM " << m << std::endl;
  //std::cout << "EQ CTRLPT DIM " << n << std::endl;

  PathPlannerRecedingHoriz *thisPP = static_cast<PathPlannerRecedingHoriz *>(data);

  // Interpolation time
  Eigen::RowVectorXd interpTime ( Eigen::RowVectorXd::LinSpaced(thisPP->noCtrlPts, 0.0, x[0]) );

  // Interpolation points ( noCtrlPts points )
  MySpline::ControlPointVectorType ctrlPts(thisPP->splDim, thisPP->noCtrlPts);
  ctrlPts.row(0) = interpTime;

  for ( unsigned i = 0; i < n-1; ++i )
  {
    ctrlPts(i%(thisPP->splDim-1)+1, i/(thisPP->splDim-1)) = x[i+1];
    //std::cout << x[i] << std::endl;
  }

  // Get chords lengths from interpolation time
  MySpline::KnotVectorType chordLengths;
  Eigen::ChordLengths(interpTime, chordLengths);

  // Call fitting static method
  thisPP->auxSpline = Eigen::SplineFitting<MySpline>::Interpolate( ctrlPts, splDegree, chordLengths );

  //std::cout << "CTRL PTS BASED ON OPT:\n" << ctrlPts << std::endl;

  MySpline optSpline(thisPP->auxSpline.knots(), ctrlPts);

  //std::cout << "EVAL SPLINE AT END:\n" << optSpline(1.0) << std::endl;
  //std::cout << "EVAL SPLINE AT init:\n" << optSpline(0.0) << std::endl;

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > derivFlatT0;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > derivFlatTf;

  derivFlatT0 =
        optSpline.derivatives(
        0.0, aiv::FlatoutputMonocycle::flatDerivDeg
        ).bottomRows(aiv::FlatoutputMonocycle::flatDim);

  derivFlatTf =
        optSpline.derivatives(
        1.0, aiv::FlatoutputMonocycle::flatDerivDeg
        ).bottomRows(aiv::FlatoutputMonocycle::flatDim);

  //std::cout << "DERIV@0:\n" << derivFlat << std::endl;

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > pose = aiv::FlatoutputMonocycle::flatToPose ( derivFlatT0 );
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > diffPoseAtT0 = pose - thisPP->latestPose;
  diffPoseAtT0.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0) =
      pose.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0);

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > diffVelocityAtT0 =
      aiv::FlatoutputMonocycle::flatToVelocity ( derivFlatT0 ) - thisPP->latestVelocity;

  pose = aiv::FlatoutputMonocycle::flatToPose ( derivFlatTf );
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > diffPoseAtTf = pose - thisPP->targetedPose;
  diffPoseAtTf.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0) +=
      thisPP->latestPose.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0);

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > diffVelocityAtTf =
      aiv::FlatoutputMonocycle::flatToVelocity ( derivFlatTf ) - thisPP->targetedVelocity;

  int i = 0;
  //std::cout << "POS ERROR\n";
  for (; i < aiv::FlatoutputMonocycle::poseDim; ++i )
  {
    result[i] = diffPoseAtT0[i];
    //std::cout << ' ' << result[i];
  }
  //std::cout << "\nVEL ERROR\n";
  int j;
  for ( j = i; j-i < aiv::FlatoutputMonocycle::velocityDim; ++j )
  {
    result[j] = diffVelocityAtT0[j-i];
    //std::cout << ' ' << result[j];
  }
  for (i = j; i-j < aiv::FlatoutputMonocycle::poseDim; ++i )
  {
    result[i] = diffPoseAtTf[i-j];
    //std::cout << ' ' << result[i];
  }
  //std::cout << "\nVEL ERROR\n";
  for ( j = i; j-i < aiv::FlatoutputMonocycle::velocityDim; ++j )
  {
    result[j] = diffVelocityAtTf[j-i];
    //std::cout << ' ' << result[j];
  }

  /*std::cout << "\nEQ FUNC CALL RESULTS:\n";

  for (unsigned i = 0; i<m; ++i)
  {
    std::cout << ' ' << result[i];
  }
  std::cout << '\n';*/

  if (grad)
  {
    int i=0;
    std::cout << "grad order ? = " << n*m <<std::endl;
    //while (true)
      //std::cout << "grad@" << i++ << " = " << grad[i] << std::endl;
    //system("pause");
  }
  /*else
  {
    system("pause");
  }*/

  //std::cout << m << std::endl;
  //system("pause");
  return;
}

void PathPlannerRecedingHoriz::ineqFuncLS(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data)
{
  //std::cout << "INEQ FUN CALL" << std::endl;

  //std::cout << "IEQ RESUL DIM " << m << std::endl;
  //std::cout << "IEQ CTRLPT DIM " << n << std::endl;

  PathPlannerRecedingHoriz *thisPP = static_cast<PathPlannerRecedingHoriz *>(data);

  // Interpolation time
  Eigen::RowVectorXd interpTime ( Eigen::RowVectorXd::LinSpaced(thisPP->noCtrlPts, 0.0, x[0]) );

  // Interpolation points ( noCtrlPts points )
  MySpline::ControlPointVectorType ctrlPts(thisPP->splDim, thisPP->noCtrlPts);
  ctrlPts.row(0) = interpTime;

  for ( unsigned i = 0; i < n-1; ++i )
  {
    ctrlPts(i%(thisPP->splDim-1)+1, i/(thisPP->splDim-1)) = x[i+1];
    //std::cout << x[i] << std::endl;
  }

  // Get chords lengths from interpolation time
  MySpline::KnotVectorType chordLengths;
  Eigen::ChordLengths(interpTime, chordLengths);

  // Call fitting static method
  thisPP->auxSpline = Eigen::SplineFitting<MySpline>::Interpolate( ctrlPts, splDegree, chordLengths );

  //std::cout << "CTRL PTS BASED ON OPT:\n" << ctrlPts << std::endl;

  MySpline optSpline(thisPP->auxSpline.knots(), ctrlPts);

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > derivFlat;

  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > velocity;

  #pragma omp parallel for
  for ( int i = 1; i < int(thisPP->noTimeSamples)-1; ++i )
  {

    derivFlat =
        optSpline.derivatives(
        double(i)/(thisPP->noTimeSamples-1), aiv::FlatoutputMonocycle::flatDerivDeg
        ).bottomRows(aiv::FlatoutputMonocycle::flatDim);

    velocity = aiv::FlatoutputMonocycle::flatToVelocity ( derivFlat );
    /*std::cout << "DERIV \n" << derivFlat << std::endl;

    std::cout << "VEL \n" << velocity.cwiseAbs() << std::endl;
    std::cout << "MVEL \n" << thisPP->maxVelocity << std::endl;*/

    for ( int j = 0; j < aiv::FlatoutputMonocycle::velocityDim; ++j )
    {
      result[j+(i-1)*aiv::FlatoutputMonocycle::velocityDim] = velocity.cwiseAbs()(j, 0) - thisPP->maxVelocity(j,0);
    }

  }

  /*std::cout << "INEQ FUN CALL" << std::endl;

  std::cout << "\nINEQ FUNC CALL RESULTS:\n";

  for (unsigned i = 0; i<m; ++i)
  {
    std::cout << ' ' << result[i];
  }
  std::cout << '\n';*/

  //std::cout << std::endl;
  if (grad)
  {
  }
  /*else
  {
    system("pause");
  }*/
  return;
}

}
// cmake:sourcegroup=PathPlanner