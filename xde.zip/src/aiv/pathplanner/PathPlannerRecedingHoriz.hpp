#ifndef __AIV_PATHPLANNERRECEDINGHORIZ_HPP__
#define __AIV_PATHPLANNERRECEDINGHORIZ_HPP__
#pragma once

#include "aiv/pathplanner/PathPlanner.hpp"
#include "aiv/pathplanner/FlatoutputMonocycle.hpp"
#include <unsupported/Eigen/Splines>
#include <boost/thread.hpp>
#include <fstream>
#include "sys/timer.h"

namespace aiv {

class PathPlannerRecedingHoriz: public PathPlanner
{

/*____________________________________________ Members ____________________________________________*/
public:
  static const unsigned splDegree = aiv::FlatoutputMonocycle::flatDerivDeg + 1; // spline degree defined by Defoort is = splDegree + 1    
  static const unsigned splDim = aiv::FlatoutputMonocycle::flatDim + 1; // spline dimension
private:

  // Solution "flat output" b-spline representation
  typedef Eigen::Spline< double, splDim, splDegree > MySpline;

  // Planning parameters
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > initPose;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, 1 > initFlat;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > initVelocity;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > targetedPose;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, 1 > targetedFlat;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > targetedVelocity;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > maxVelocity;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > maxAcceleration;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, 1 > latestFlat;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > latestPose;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > mLatestPose;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > basePose;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > latestVelocity;
  bool mindAcceleration;

  double compHorizon;         // computation horizon
  double refPlanHorizon;      // planning horizon
  double finalPlanHorizon;    // planning horizon
  double planHorizon;         // planning horizon
  bool lastPlanExec;
  unsigned noTimeSamples;     // number of  time samples taken within a planning horizon
  unsigned noIntervNonNull;   // number of non null knots intervals
  unsigned noCtrlPts;         // number of control points

  double lastStepMinDist;
  double optAccuracy;
  unsigned lastMaxIteration;
  unsigned firstMaxIteration;
  unsigned interMaxIteration;
  double conflictFreePathDeviation;
  double interRobotSafetyDist;
  double maxStraightDist;

  //xde::sys::Timer plTimer;
  double updateTimeStep;
  unsigned long long updateCallCntr;

  boost::mutex planOngoingMutex;
  bool standAlone;

  enum PlanStage { INITSTAGE, INTERSTAGE, FINALSTAGE } planStage;

  MySpline solSpline;
  MySpline auxSpline;
  double estTime;

  boost::thread planThread;

  int ongoingPlanIdx;
  int executingPlanIdx;

  // Planning outputs
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > nextVelocityRef;
  Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > nextPoseRef;
  //std::ofstream points_ts;

/*____________________________________________ Methods ____________________________________________*/

private:
  void plan();
  Eigen::Array< double, 1, Eigen::Dynamic > genKnots ( const double initT, const double finalT, const bool nonUniform );
  void solveOptPbl();

public:
  PathPlannerRecedingHoriz(std::string name, double updateTimeStep);

  ~PathPlannerRecedingHoriz();

  void init(
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &initPose, // x, y, theta
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &initVelocity, // v, w
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &targetedPose, // x, y, theta
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &targetedVelocity, // v, w
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &maxVelocity, // v, w
    double compHorizon,
    double refPlanHorizon,
    unsigned noTimeSamples,
    unsigned noIntervNonNull);

  void init(
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &initPose, // x, y, theta
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &initVelocity, // v, w
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &targetedPose, // x, y, theta
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &targetedVelocity, // v, w
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &maxVelocity, // v, w
    const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &maxAcceleration, // dv, dw
    double compHorizon,
    double refPlanHorizon,
    unsigned noTimeSamples,
    unsigned noIntervNonNull);

  void setOption ( std::string optionName, double optionValue );
  
  void update(const Eigen::Displacementd & realPose, const Eigen::Twistd &realVelocity);

  double getLinVelocity () { return this->nextVelocityRef(aiv::FlatoutputMonocycle::linSpeedIdx); }
  double getAngVelocity () { return this->nextVelocityRef(aiv::FlatoutputMonocycle::angSpeedIdx); }

  double getXPosition() { return this->nextPoseRef(aiv::FlatoutputMonocycle::posIdx); }
  double getYPosition() { return this->nextPoseRef(aiv::FlatoutputMonocycle::posIdx+1); }
  double getOrientation() { return this->nextPoseRef(aiv::FlatoutputMonocycle::posIdx+2); }

  static double objectFunc(unsigned n, const double *x, double *grad, void *my_func_data);
  static double objectFuncLS(unsigned n, const double *x, double *grad, void *my_func_data);
  static void eqFunc(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data);
  static void ineqFunc(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data);
  static void eqFuncLS(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data);
  static void ineqFuncLS(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data);

};


}

#endif // __AIV_PATHPLANNERRECEDINGHORIZ_HPP__

// cmake:sourcegroup=PathPlanner
