#ifndef __AIV_CONTROLLERMONOCYCLE_HPP__
#define __AIV_CONTROLLERMONOCYCLE_HPP__
#pragma once

#include "Controller.hpp"

namespace aiv {

class ControllerMonocycle : public Controller
{
  
public:
	ControllerMonocycle(std::string name);
	void init();
  void update();

	double get_RightWheelVelocity()	const	{return v_r;}	// m/s
	double get_LeftWheelVelocity()	const	{return v_l;}	// m/s

	double  v_r, v_l;
  
};

}

#endif // __AIV_CONTROLLERMONOCYCLE_HPP__

// cmake:sourcegroup=ControllerMonocycle