#include "ControllerMonocycle.hpp"

namespace aiv {

ControllerMonocycle::ControllerMonocycle(std::string name)
  : Controller(name),
v_r(0.0),
v_l(0.0)
{
}

void ControllerMonocycle::init()
{
  // Public Variables
  this->v_r     = 0.0;	// Right wheel velocity (m/s)
  this->v_l     = 0.0;	// Left wheel velocity (m/s)
}
	
void ControllerMonocycle::update()
{
  this->v_r     =  1.0;
  this->v_l     = -1.0;
}

}


// cmake:sourcegroup=ControllerMonocycle