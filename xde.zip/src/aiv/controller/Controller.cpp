#include "Controller.hpp"

namespace aiv 
{

Controller::Controller(std::string n)
  : name(n)
{
}

void Controller::update()
{
}

std::string Controller::getName()
{
  return name;
}

}


// cmake:sourcegroup=Controller