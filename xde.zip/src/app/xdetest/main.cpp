void test_HapticManipulator();
void test_PositionBasedManipulator();
//void test_Human();

int main()
{
  test_PositionBasedManipulator();
}
