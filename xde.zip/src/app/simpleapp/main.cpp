/**
 *
 *
 * \date 08/2015
 * \author CEA/DRT/LIST/DIASI/LRI
 * \author E. Lucet
 * \author J. M. Mendes Filho
 *
 * @par Licence
 * Copyright � 2015 CEA
 */
//==============================================================================
// MOBILE ROBOT PATH FOLLOWING APPLICATION
//==============================================================================

#include "sys/timer.h"
#include <iostream>
#include <math.h>
//#include <boost/property_tree/ptree.hpp>
//#include <boost/property_tree/xml_parser.hpp>
//#include <boost/foreach.hpp>

#include "aiv/helpers/AppBuilder.hpp"
#include "aiv/robot/AIV.hpp"
#include "aiv/robot/AIVMonocycle.hpp"
#include "aiv/controller/ControllerMonocycle.hpp"
#include "aiv/pathplanner/PathPlannerRecedingHoriz.hpp"

//#define foreach_ BOOST_FOREACH

using namespace Eigen;

/*
This main would be easily replaced in futur by a python script
*/

//void initFromXML(const std::string &filename, MplInfo *mplInput, double *speedupFactor);

int main()
{
  //xde::sys::Timer updateTimer;
  xde::sys::Timer wallTimer;
  //wallTimer.ResetTime();
  //updateTimer.ResetTime();

	aiv::ApplicationBuilder builder;
  //aiv::Application * app = builder.buildSimpleCollisionApp();
  aiv::Application * app = builder.buildSimpleAdeptApp();

	aiv::AIVMonocycle * vehicle = dynamic_cast<aiv::AIVMonocycle*>(app->getVehicleByName("AdeptLynx0"));

  // Get vehicle path planner so we can initialize/configure it properly
  aiv::PathPlannerRecedingHoriz * v1pathplanner = dynamic_cast<aiv::PathPlannerRecedingHoriz*>(vehicle->getPathPlanner());

  //aiv::AIVMonocycle * vehicle2 = dynamic_cast<aiv::AIVMonocycle*>(app->getVehicleByName("AdeptLynx_2"));

  {
    // LOGGING FILES
    std::ofstream mpl_ts;
    std::ofstream ctrl_ts;
    std::ofstream real_ts;

    mpl_ts.open ("mpl_ts.csv");
    real_ts.open ("real_ts.csv");

    //unsigned int i = 0;
    double tic, toc, simTic;
    double appTimeStep = app->getTimeStep() * 1000.0;
    double appSimSpeed = app->getSimSpeed();

    double vVel, wVel, xPos, yPos, tPos;
    
    Eigen::Displacementd realPose;
    Eigen::Quaternion<double> q;
    Eigen::QuaternionBase<Eigen::Quaternion<double> >::Vector3 coordXB;

    Eigen::Twistd realVelocity;
    double realVVel, realWVel;

    double remainingTime;

    double wheelRadius = vehicle->getWheelRadius();
    double track = vehicle->getTrack();

    //while(1)
    wallTimer.ResetTime();
    for(int i=1; true; ++i)
    {
      tic = wallTimer.GetTime();

      app->update();

      // Apply controller output
		  //vehicle->setDesiredRightWheelVelocity(dynamic_cast<aiv::ControllerMonocycle*>(vehicle->getController())->get_RightWheelVelocity());	//rad/s
		  //vehicle->setDesiredLeft:WheelVelocity( dynamic_cast<aiv::ControllerMonocycle*>(vehicle->getController())->get_LeftWheelVelocity());	//rad/s

      // GET MPL OUTPUT
      vVel = v1pathplanner->getLinVelocity();
      wVel = v1pathplanner->getAngVelocity();
      xPos = v1pathplanner->getXPosition();
      yPos = v1pathplanner->getYPosition();
      tPos = v1pathplanner->getOrientation();

      // Ignoring the controller and applying the the velocities from the planner
      vehicle->setDesiredRightWheelVelocity((vVel+wVel*track/2)/wheelRadius);	//rad/s
		  vehicle->setDesiredLeftWheelVelocity((vVel-wVel*track/2)/wheelRadius);	//rad/s

      // REAL POSITION is [x, y, z, q], where q = [q1, q2, q3, q4] a quarternion representation of the orientation
      realPose = vehicle->getCurrentPosition();

      // Getting robot's orientation projected in the ground plane (unless the robot is flying this is the right orientation)
      // 1. get the quaternion part of the displacement
      q = Eigen::Quaternion<double>(realPose.qw(), realPose.qx(), realPose.qy(), realPose.qz());
      // 2. rotation of UnityX by the quaternion q (i.e. x of the robot frame wrt the absolute frame)
      coordXB = q._transformVector(Vector3d::UnitX());

      // REAL VELOCITY is [wx wy wz vx vy vz] wrt the robot frame
      realVelocity = vehicle->getCurrentVelocity(); // (w, v)

      realVVel = realVelocity.block<2,1>(3,0).norm(); // sqrt(vx^2 + vy^2) linear speed in the robot plane xy
      realWVel = realVelocity.topRows(3).z(); // rotation around z of the robot frame

      /*if(i++ > 200)
      {
        i = 0;
        app->printPerformanceReport(std::cout);
      }*/

      simTic = appTimeStep/1000. * i;

      toc = wallTimer.GetTime();

      // SAVE TO FILE
      mpl_ts << toc/1000.  << ",";
      mpl_ts << simTic << ",";
      mpl_ts << xPos << ",";
      mpl_ts << yPos << ",";
      mpl_ts << tPos << ",";
      mpl_ts << vVel << ",";
      mpl_ts << wVel << ",";
      mpl_ts << "\n";

      real_ts << toc/1000. << ",";
      real_ts << simTic << ",";
      real_ts << realPose.x() << ",";
      real_ts << realPose.y() << ",";
      real_ts << atan2(coordXB.y(), coordXB.x()) << ",";
      real_ts << realVVel << ",";
      real_ts << realWVel << ",";
      real_ts << realVelocity[0] << ",";
      real_ts << realVelocity[1] << ",";
      real_ts << realVelocity[2] << ",";
      real_ts << realVelocity[3] << ",";
      real_ts << realVelocity[4] << ",";
      real_ts << realVelocity[5] << ",";
      real_ts << "\n";

      toc = wallTimer.GetTime();

      remainingTime = std::max( 0.0, appTimeStep/appSimSpeed - ( toc-tic ) ); // So we have a simulation time equals to the real time...
      xde::sys::Timer::Sleep( remainingTime ); // ... (it does not impact on the physics of the simulation)
      
    }
    mpl_ts.close();
    real_ts.close();
  }

	return 0;
}

//Dans AppBuilder.cpp nous utilisons la fonction buildSimpleAdeptApp()
//
//Dans cette fonction, on cr�e l�objet � scenebuilder � de type SceneBuilder
//
//Puis on s�en sert pour cr�er les objets de la sc�ne, par exemple le sol : ground = scenebuilder.addFixedObject( �
//
//C�est simple, tu fais pareil pour cr�er les obstacles : obstacle = scenebuilder.addFixedObject( �
//
//En regardant les d�tails de la fonction addFixedObject() dans la classe SceneBuilder.cpp (ligne 96)
//
//Pour cela, tu devras utiliser un fichier dae ou bien 3dxml qui contient la g�om�trie de ton obstacle, que tu auras mis dans le r�pertoire ../../../../share/resources/scenes (comme par exemple c�est d�j� le cas pour le sol ../../../../share/resources/scenes/ground.dae).


//Affichage des trajectoires de consigne et r�elle du v�hicule : D�j� fait il y a un an mais sous python :
//
//# Visual lines of the vehicle trajectory
//line_blue = lgsm.vector(0.0, 0.0, 1.0, 1.0) ## R G B transparence (alpha)
//graph.s.Connectors.IConnectorLine.new("iclf", "i_line", "mainScene", line_blue, True)
//i_line = graph.getPort("i_line")
//o_line = controller.getPort("line")
//i_line.connectTo(o_line)
//
//Et ensuite dans une boucle Orocos OCL avec :
//
//this->addPort("line", out_line); 
//
//this->line = std::vector<double>(6);
//memset(&this->line[0], 0, 6*sizeof(double));
//�
//this->line[i] =�
//�
//out_line.write(this->line);

//void initFromXML(const std::string &filename, MplInfo *mplInput, double *speedupFactor)
//{
//  using boost::property_tree::ptree;
//  ptree pt;
//
//  read_xml(filename, pt);
//
//  foreach_(ptree::value_type &v0, pt.get_child("config"))
//  {
//    if ( v0.first == "speedupfactor" )
//      *speedupFactor = std::max(0.0, v0.second.get<double>("<xmlattr>.t", 0.0));
//
//    else if ( v0.first == "robotstate" )
//      foreach_(ptree::value_type &v, pt.get_child("config.robotstate"))
//      {
//        if ( v.first == "initpose" )
//          mplInput->initPose << v.second.get<double>("<xmlattr>.x", 0.0),
//              v.second.get<double>("<xmlattr>.y", 0.0),
//              v.second.get<double>("<xmlattr>.t", 0.0);
//        else if ( v.first == "goalpose" )
//          mplInput->goalPose << v.second.get<double>("<xmlattr>.x", 0.0),
//              v.second.get<double>("<xmlattr>.y", 0.0),
//              v.second.get<double>("<xmlattr>.t", 0.0);
//        else if ( v.first == "initvelo" )
//
//          mplInput->initVelo << v.second.get<double>("<xmlattr>.x", 0.0),
//              v.second.get<double>("<xmlattr>.y", 0.0);
//        else if ( v.first == "goalvelo" )
//          mplInput->goalVelo << v.second.get<double>("<xmlattr>.x", 0.0),
//              v.second.get<double>("<xmlattr>.y", 0.0);
//        else if ( v.first == "maxvelo" )
//          mplInput->maxVelo << v.second.get<double>("<xmlattr>.l", 10000.0),
//              v.second.get<double>("<xmlattr>.a", 10000.0);
//        else if ( v.first == "maxacc" )
//          mplInput->maxAcc << v.second.get<double>("<xmlattr>.l", 10000.0),
//              v.second.get<double>("<xmlattr>.a", 10000.0);
//      }
//
//    else if ( v0.first == "mpmethod" )
//      foreach_(ptree::value_type &v, pt.get_child("config.mpmethod"))
//      {
//        if ( v.first == "comphorizon" )
//          mplInput->Tc = v.second.get<double>("<xmlattr>.t", 0.5);
//        else if ( v.first == "planninghorizon" )
//          mplInput->Tp = v.second.get<double>("<xmlattr>.t", 1.5);
//        else if ( v.first == "sampling" )
//          mplInput->Ns = v.second.get<unsigned>("<xmlattr>.n", 15);
//        else if ( v.first == "interknots" )
//          mplInput->intKnots = v.second.get<unsigned>("<xmlattr>.n", 5);
//        else if ( v.first == "terminationdist" )
//          mplInput->terminationDist = v.second.get<double>("<xmlattr>.d", 0.5);
//        else if ( v.first == "interrobotsafetydist" )
//          mplInput->interRobotSafetyDist = v.second.get<double>("<xmlattr>.d", 0.1);
//        else if ( v.first == "conflictfreepathdeviation" )
//          mplInput->conflictFreePathDeviation = v.second.get<double>("<xmlattr>.d", 3.0);
//      }
//
//    else if ( v0.first == "optimizer" )
//      foreach_(ptree::value_type &v, pt.get_child("config.optimizer"))
//      {
//        if ( v.first == "iteraction" )
//        {
//          mplInput->termMaxIterac = v.second.get<unsigned>("<xmlattr>.t", 100);
//          mplInput->firstMaxIterac = v.second.get<unsigned>("<xmlattr>.f", 100);
//          mplInput->interMaxIterac = v.second.get<unsigned>("<xmlattr>.i", 100);
//        }
//        else if ( v.first == "accuracy" )
//          mplInput->optAccuracy = v.second.get<double>("<xmlattr>.a", 10e-4);
//      }
//  }
  //write_xml(std::cout, pt);

  //std::cout << "initPose: " << mplInput->initPose << std::endl;
  //std::cout << "initVelo: " << mplInput->initVelo << std::endl;
  //std::cout << "goalPose: " << mplInput->goalPose << std::endl;
  //std::cout << "goalVelo: " << mplInput->goalVelo << std::endl;
  //std::cout << "maxVelo: " << mplInput->maxVelo << std::endl;
  //std::cout << "maxAcc: " << mplInput->maxAcc << std::endl;
  //std::cout << "Tc: " << mplInput->Tc << std::endl;
  //std::cout << "Tp: " << mplInput->Tp << std::endl;
  //std::cout << "Ns: " << mplInput->Ns << std::endl;
  //std::cout << "intKnots: " << mplInput->intKnots << std::endl;
  //std::cout << "terminationDist: " << mplInput->terminationDist << std::endl;
  //std::cout << "conflictFreePathDeviation: " << mplInput->conflictFreePathDeviation << std::endl;
  //std::cout << "interRobotSafetyDist: " << mplInput->interRobotSafetyDist << std::endl;
  //std::cout << "optAccuracy: " << mplInput->optAccuracy << std::endl;
  //std::cout << "termMaxIterac: " << mplInput->termMaxIterac << std::endl;
  //std::cout << "firstMaxIterac: " << mplInput->firstMaxIterac << std::endl;
  //std::cout << "interMaxIterac: " << mplInput->interMaxIterac << std::endl;

//  return;
//}